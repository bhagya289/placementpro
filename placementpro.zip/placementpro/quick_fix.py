# quick_fix.py
import sqlite3
import os

print("=" * 50)
print("🔧 QUICK DATABASE FIX")
print("=" * 50)

# Connect to database
db_path = 'placementpro.db'
if not os.path.exists(db_path):
    print("❌ Database file not found!")
    exit(1)

conn = sqlite3.connect(db_path)
cursor = conn.cursor()

# Check if verified column exists
cursor.execute("PRAGMA table_info(users)")
columns = cursor.fetchall()
column_names = [col[1] for col in columns]

print(f"\n📊 Current columns: {', '.join(column_names)}")

if 'verified' not in column_names:
    print("\n➕ Adding 'verified' column...")
    cursor.execute("ALTER TABLE users ADD COLUMN verified BOOLEAN DEFAULT 0")
    print("✅ Verified column added!")
else:
    print("\n✅ Verified column already exists!")

# Update existing users to be verified
cursor.execute("UPDATE users SET verified = 1 WHERE verified IS NULL")
updated = cursor.rowcount
print(f"✅ Updated {updated} users to verified status")

conn.commit()
conn.close()

print("\n" + "=" * 50)
print("✅ FIX COMPLETE! Restart your Flask app.")
print("=" * 50)