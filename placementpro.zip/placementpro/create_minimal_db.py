# create_minimal_db.py
import sqlite3
import os
from werkzeug.security import generate_password_hash
from datetime import datetime

print("=" * 60)
print("🗄️  CREATING MINIMAL DATABASE")
print("=" * 60)

# Delete existing database
db_path = 'placementpro.db'
if os.path.exists(db_path):
    os.remove(db_path)
    print(f"✅ Deleted old database")

# Create new database
conn = sqlite3.connect(db_path)
cursor = conn.cursor()

# Create users table with ALL columns
print("\n📦 Creating users table...")
cursor.execute('''
CREATE TABLE users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username VARCHAR(80) UNIQUE NOT NULL,
    email VARCHAR(120) UNIQUE NOT NULL,
    password_hash VARCHAR(200) NOT NULL,
    role VARCHAR(20) NOT NULL,
    full_name VARCHAR(100),
    profile_pic VARCHAR(200),
    verified BOOLEAN DEFAULT 0,
    created_at DATETIME
)
''')

# Verify the table structure
cursor.execute("PRAGMA table_info(users)")
columns = cursor.fetchall()
print("\n📊 Users table columns:")
for col in columns:
    col_name = col[1]
    col_type = col[2]
    mark = "✅ VERIFIED" if col_name == 'verified' else ""
    print(f"  • {col_name:15} ({col_type:10}) {mark}")

# Insert test users
print("\n👤 Inserting test users...")

# Generate password hashes
admin_hash = generate_password_hash('admin123')
student_hash = generate_password_hash('student123')
alumni_hash = generate_password_hash('alumni123')

# Insert TPO
cursor.execute('''
INSERT INTO users (username, email, password_hash, role, full_name, verified, created_at)
VALUES (?, ?, ?, ?, ?, ?, ?)
''', ('tpo', 'tpo@college.edu', admin_hash, 'tpo', 'Dr. Placement Officer', 1, datetime.now()))
print("  ✓ TPO user inserted")

# Insert Student
cursor.execute('''
INSERT INTO users (username, email, password_hash, role, full_name, verified, created_at)
VALUES (?, ?, ?, ?, ?, ?, ?)
''', ('john_student', 'john@college.edu', student_hash, 'student', 'John Doe', 1, datetime.now()))
student_id = cursor.lastrowid
print("  ✓ Student user inserted")

# Insert Alumni
cursor.execute('''
INSERT INTO users (username, email, password_hash, role, full_name, verified, created_at)
VALUES (?, ?, ?, ?, ?, ?, ?)
''', ('jane_alumni', 'jane@alumni.com', alumni_hash, 'alumni', 'Jane Smith', 1, datetime.now()))
print("  ✓ Alumni user inserted")

# Commit changes
conn.commit()

# Final verification
print("\n🔍 Final verification:")
cursor.execute("SELECT id, email, role, verified FROM users")
users = cursor.fetchall()
for user in users:
    verified = "✅ Verified" if user[3] == 1 else "❌ Not Verified"
    print(f"  • {user[1]} ({user[2]}) - {verified}")

conn.close()

print("\n" + "=" * 60)
print("✅ DATABASE CREATED SUCCESSFULLY!")
print("=" * 60)
print("\n📝 LOGIN CREDENTIALS:")
print("-" * 40)
print("TPO:     tpo@college.edu / admin123")
print("Student: john@college.edu / student123")
print("Alumni:  jane@alumni.com / alumni123")
print("-" * 40)