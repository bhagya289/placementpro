# create_test_users.py
from app import app, db, User, Student, Alumni
from werkzeug.security import generate_password_hash

with app.app_context():
    # Drop all tables and recreate
    db.drop_all()
    db.create_all()
    
    # Create TPO user
    tpo = User(
        username='tpo',
        email='tpo@college.edu',
        password_hash=generate_password_hash('admin123'),
        role='tpo',
        full_name='Dr. Placement Officer'
    )
    db.session.add(tpo)
    
    # Create Student user
    student = User(
        username='john_student',
        email='john@college.edu',
        password_hash=generate_password_hash('student123'),
        role='student',
        full_name='John Doe'
    )
    db.session.add(student)
    db.session.flush()  # Get the ID
    
    # Create Student profile
    student_profile = Student(
        user_id=student.id,
        enrollment_no='2024CS001',
        branch='Computer Science',
        semester=6,
        cgpa=8.5,
        backlogs=0,
        tenth_percentage=89.5,
        twelfth_percentage=87.0,
        graduation_percentage=85.0,
        skills='Python, Java, SQL, JavaScript'
    )
    db.session.add(student_profile)
    
    # Create Alumni user
    alumni = User(
        username='jane_alumni',
        email='jane@alumni.com',
        password_hash=generate_password_hash('alumni123'),
        role='alumni',
        full_name='Jane Smith'
    )
    db.session.add(alumni)
    db.session.flush()
    
    # Create Alumni profile
    alumni_profile = Alumni(
        user_id=alumni.id,
        company='Google',
        position='Senior Software Engineer',
        batch=2020,
        linkedin='https://linkedin.com/in/janesmith',
        available_for_mentorship=True
    )
    db.session.add(alumni_profile)
    
    db.session.commit()
    
    print("✅ Database created successfully!")
    print("\nTest users created:")
    print("=" * 50)
    print("TPO:     tpo@college.edu / admin123")
    print("Student: john@college.edu / student123")
    print("Alumni:  jane@alumni.com / alumni123")
    print("=" * 50)