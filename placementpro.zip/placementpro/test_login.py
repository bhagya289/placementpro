# test_login.py
import sqlite3
from werkzeug.security import check_password_hash

def test_login():
    print("=" * 60)
    print("🔐 TESTING LOGIN WITH DATABASE")
    print("=" * 60)
    
    # Connect to database
    conn = sqlite3.connect('placementpro.db')
    cursor = conn.cursor()
    
    # Test each user
    test_users = [
        ('tpo@college.edu', 'admin123', 'tpo'),
        ('john@college.edu', 'student123', 'student'),
        ('jane@alumni.com', 'alumni123', 'alumni')
    ]
    
    for email, password, expected_role in test_users:
        print(f"\n📧 Testing: {email}")
        
        # Get user from database
        cursor.execute('''
        SELECT id, email, password_hash, role, verified 
        FROM users 
        WHERE email = ?
        ''', (email,))
        
        user = cursor.fetchone()
        
        if user:
            user_id, user_email, password_hash, role, verified = user
            print(f"  ✓ User found in database")
            print(f"    Role: {role}, Verified: {verified}")
            
            # Check password
            if check_password_hash(password_hash, password):
                print(f"  ✓ Password correct")
                if role == expected_role:
                    print(f"  ✓ Role matches: {role}")
                else:
                    print(f"  ❌ Role mismatch: expected {expected_role}, got {role}")
            else:
                print(f"  ❌ Password incorrect")
        else:
            print(f"  ❌ User not found in database")
    
    conn.close()
    
    print("\n" + "=" * 60)

if __name__ == '__main__':
    test_login()