# app.py
from flask import Flask, render_template, request, redirect, url_for, flash, session, jsonify
from flask_sqlalchemy import SQLAlchemy
from flask_login import LoginManager, UserMixin, login_user, login_required, logout_user, current_user
from werkzeug.security import generate_password_hash, check_password_hash
from datetime import datetime, timedelta
import json
import os
import random
import string
from functools import wraps

app = Flask(__name__)
app.config['SECRET_KEY'] = 'your-secret-key-here-change-this-in-production'
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///placementpro.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

db = SQLAlchemy(app)
login_manager = LoginManager(app)
login_manager.login_view = 'login'

# Generate random OTP
def generate_otp():
    return ''.join(random.choices(string.digits, k=6))

# Send email function (simplified for demo)
def send_otp_email(email, otp):
    print(f"\n" + "="*50)
    print(f"📧 OTP for {email}: {otp}")
    print("="*50 + "\n")
    return True

# Database Models
class User(UserMixin, db.Model):
    __tablename__ = 'users'
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(80), unique=True, nullable=False)
    email = db.Column(db.String(120), unique=True, nullable=False)
    password_hash = db.Column(db.String(200), nullable=False)
    role = db.Column(db.String(20), nullable=False)
    full_name = db.Column(db.String(100))
    profile_pic = db.Column(db.String(200))
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    def is_verified(self):
        return True

class Student(db.Model):
    __tablename__ = 'students'
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), unique=True)
    enrollment_no = db.Column(db.String(20), unique=True)
    branch = db.Column(db.String(50), default='Not Specified')
    semester = db.Column(db.Integer, default=1)
    cgpa = db.Column(db.Float, default=0.0)
    backlogs = db.Column(db.Integer, default=0)
    tenth_percentage = db.Column(db.Float, default=0.0)
    twelfth_percentage = db.Column(db.Float, default=0.0)
    graduation_percentage = db.Column(db.Float, default=0.0)
    skills = db.Column(db.Text, default='')
    projects = db.Column(db.Text, default='')
    internships = db.Column(db.Text, default='')
    achievements = db.Column(db.Text, default='')
    resume_url = db.Column(db.String(200), default='')
    
    user = db.relationship('User', backref='student_profile')

class Alumni(db.Model):
    __tablename__ = 'alumni'
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), unique=True)
    company = db.Column(db.String(100), default='Not Specified')
    position = db.Column(db.String(100), default='Not Specified')
    batch = db.Column(db.Integer, default=2020)
    linkedin = db.Column(db.String(200), default='')
    available_for_mentorship = db.Column(db.Boolean, default=False)
    mentorship_hours = db.Column(db.String(200), default='')
    
    user = db.relationship('User', backref='alumni_profile')

class Drive(db.Model):
    __tablename__ = 'drives'
    id = db.Column(db.Integer, primary_key=True)
    company_name = db.Column(db.String(100))
    job_title = db.Column(db.String(100))
    description = db.Column(db.Text)
    min_cgpa = db.Column(db.Float)
    max_backlogs = db.Column(db.Integer)
    eligible_branches = db.Column(db.Text)
    eligible_courses = db.Column(db.Text)
    package = db.Column(db.String(50))
    location = db.Column(db.String(100))
    last_date = db.Column(db.DateTime)
    drive_date = db.Column(db.DateTime)
    status = db.Column(db.String(20), default='upcoming')
    created_by = db.Column(db.Integer, db.ForeignKey('users.id'))
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

class Application(db.Model):
    __tablename__ = 'applications'
    id = db.Column(db.Integer, primary_key=True)
    student_id = db.Column(db.Integer, db.ForeignKey('students.id'))
    drive_id = db.Column(db.Integer, db.ForeignKey('drives.id'))
    status = db.Column(db.String(20), default='applied')
    applied_date = db.Column(db.DateTime, default=datetime.utcnow)
    interview_date = db.Column(db.DateTime)
    interview_slot = db.Column(db.String(50))
    feedback = db.Column(db.Text)
    
    student = db.relationship('Student', backref='applications')
    drive = db.relationship('Drive', backref='applications')

class JobReferral(db.Model):
    __tablename__ = 'job_referrals'
    id = db.Column(db.Integer, primary_key=True)
    alumni_id = db.Column(db.Integer, db.ForeignKey('alumni.id'))
    company = db.Column(db.String(100))
    position = db.Column(db.String(100))
    description = db.Column(db.Text)
    requirements = db.Column(db.Text)
    experience_level = db.Column(db.String(50))
    location = db.Column(db.String(100))
    apply_link = db.Column(db.String(200))
    posted_date = db.Column(db.DateTime, default=datetime.utcnow)
    expires_on = db.Column(db.DateTime)
    
    alumni = db.relationship('Alumni', backref='referrals')

class MentorshipSession(db.Model):
    __tablename__ = 'mentorship_sessions'
    id = db.Column(db.Integer, primary_key=True)
    alumni_id = db.Column(db.Integer, db.ForeignKey('alumni.id'))
    student_id = db.Column(db.Integer, db.ForeignKey('students.id'))
    topic = db.Column(db.String(200))
    date_time = db.Column(db.DateTime)
    duration = db.Column(db.Integer)
    status = db.Column(db.String(20), default='scheduled')
    notes = db.Column(db.Text)
    
    alumni = db.relationship('Alumni', backref='mentorship_sessions_given')
    student = db.relationship('Student', backref='mentorship_sessions_taken')

class Notification(db.Model):
    __tablename__ = 'notifications'
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'))
    title = db.Column(db.String(200))
    message = db.Column(db.Text)
    type = db.Column(db.String(50))
    is_read = db.Column(db.Boolean, default=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    user = db.relationship('User', backref='notifications')

class ChatbotQuery(db.Model):
    __tablename__ = 'chatbot_queries'
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'))
    query = db.Column(db.Text)
    response = db.Column(db.Text)
    timestamp = db.Column(db.DateTime, default=datetime.utcnow)
    
    user = db.relationship('User', backref='chatbot_queries')

# Role-based access decorator
def role_required(*roles):
    def decorator(f):
        @wraps(f)
        def decorated_function(*args, **kwargs):
            if not current_user.is_authenticated:
                return redirect(url_for('login'))
            if current_user.role not in roles:
                flash('You do not have permission to access this page.', 'error')
                return redirect(url_for('dashboard'))
            return f(*args, **kwargs)
        return decorated_function
    return decorator

@login_manager.user_loader
def load_user(user_id):
    return User.query.get(int(user_id))

# ============= SKILL ANALYSIS FUNCTION =============
def get_skill_analysis(student):
    """Analyze student skills against company requirements"""
    
    companies = [
        {
            'name': 'Google',
            'role': 'Software Engineer',
            'required_cgpa': 8.0,
            'required_skills': ['Python', 'Java', 'Data Structures', 'Algorithms', 'SQL']
        },
        {
            'name': 'Microsoft',
            'role': 'SDE',
            'required_cgpa': 7.5,
            'required_skills': ['C++', 'Python', 'Azure', 'SQL', 'JavaScript']
        },
        {
            'name': 'Amazon',
            'role': 'SDE',
            'required_cgpa': 7.0,
            'required_skills': ['Java', 'AWS', 'System Design', 'SQL', 'Python']
        },
        {
            'name': 'TCS',
            'role': 'Software Developer',
            'required_cgpa': 6.5,
            'required_skills': ['Java', 'SQL', 'JavaScript', 'HTML', 'CSS']
        },
        {
            'name': 'Infosys',
            'role': 'System Engineer',
            'required_cgpa': 6.0,
            'required_skills': ['Python', 'SQL', 'JavaScript', 'Communication']
        },
        {
            'name': 'Deloitte',
            'role': 'Data Analyst',
            'required_cgpa': 7.0,
            'required_skills': ['Python', 'SQL', 'Excel', 'PowerBI', 'Statistics']
        }
    ]
    
    student_skills = set()
    if student and student.skills:
        student_skills = set([skill.strip() for skill in student.skills.split(',')])
    
    analysis = []
    for company in companies:
        required_skills = company['required_skills']
        missing_skills = [skill for skill in required_skills if skill not in student_skills]
        match_percentage = ((len(required_skills) - len(missing_skills)) / len(required_skills)) * 100
        
        analysis.append({
            'company': company['name'],
            'role': company['role'],
            'required_cgpa': company['required_cgpa'],
            'required_skills': required_skills,
            'missing_skills': missing_skills,
            'match_percentage': match_percentage
        })
    
    return analysis

def find_eligible_students(drive):
    """Find students eligible for a drive based on CGPA and branch"""
    eligible_branches = drive.eligible_branches.split(',') if drive.eligible_branches else []
    
    query = Student.query.filter(
        Student.cgpa >= drive.min_cgpa,
        Student.backlogs <= drive.max_backlogs
    )
    
    if eligible_branches:
        query = query.filter(Student.branch.in_(eligible_branches))
    
    return query.all()

# ============= ROUTES =============

@app.route('/')
def landing():
    return render_template('landing.html')

@app.route('/signup', methods=['GET', 'POST'])
def signup():
    if request.method == 'POST':
        username = request.form.get('username')
        email = request.form.get('email')
        password = request.form.get('password')
        role = request.form.get('role')
        full_name = request.form.get('full_name')
        
        existing_user = User.query.filter_by(email=email).first()
        if existing_user:
            flash('Email already registered. Please login.', 'error')
            return redirect(url_for('login'))
        
        existing_username = User.query.filter_by(username=username).first()
        if existing_username:
            flash('Username already taken. Please choose another.', 'error')
            return redirect(url_for('signup'))
        
        hashed_password = generate_password_hash(password)
        new_user = User(
            username=username,
            email=email,
            password_hash=hashed_password,
            role=role,
            full_name=full_name,
            created_at=datetime.utcnow()
        )
        
        db.session.add(new_user)
        db.session.commit()
        
        if role == 'student':
            enroll_no = f"ENROLL{random.randint(1000, 9999)}"
            while Student.query.filter_by(enrollment_no=enroll_no).first():
                enroll_no = f"ENROLL{random.randint(1000, 9999)}"
            
            student = Student(
                user_id=new_user.id,
                enrollment_no=enroll_no
            )
            db.session.add(student)
            db.session.commit()
            flash('Student account created successfully! Please complete your profile.', 'success')
            
        elif role == 'alumni':
            alumni = Alumni(
                user_id=new_user.id,
                company='Not Specified',
                position='Not Specified',
                batch=datetime.now().year - 1
            )
            db.session.add(alumni)
            db.session.commit()
            flash('Alumni account created successfully! Please add your company details.', 'success')
        else:
            flash('TPO account created successfully!', 'success')
        
        return redirect(url_for('login'))
    
    return render_template('signup.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        email = request.form.get('email')
        password = request.form.get('password')
        role = request.form.get('role')
        
        user = User.query.filter_by(email=email).first()
        
        if user:
            if check_password_hash(user.password_hash, password):
                if user.role == role:
                    login_user(user)
                    flash('Login successful!', 'success')
                    return redirect(url_for('dashboard'))
                else:
                    flash('Invalid role selected for this account', 'error')
            else:
                flash('Invalid password', 'error')
        else:
            flash('Email not found. Please sign up.', 'error')
    
    return render_template('login.html')

@app.route('/logout')
@login_required
def logout():
    logout_user()
    flash('You have been logged out.', 'success')
    return redirect(url_for('landing'))

@app.route('/dashboard')
@login_required
def dashboard():
    if current_user.role == 'student':
        return redirect(url_for('student_dashboard'))
    elif current_user.role == 'tpo':
        return redirect(url_for('tpo_dashboard'))
    elif current_user.role == 'alumni':
        return redirect(url_for('alumni_dashboard'))
    return redirect(url_for('home'))

# ============= STUDENT DASHBOARD =============

@app.route('/student/dashboard')
@login_required
@role_required('student')
def student_dashboard():
    student = Student.query.filter_by(user_id=current_user.id).first()
    
    if not student:
        return redirect(url_for('resume'))
    
    eligible_drives = []
    all_drives = Drive.query.filter_by(status='upcoming').all()
    
    for drive in all_drives:
        if student.cgpa >= drive.min_cgpa:
            branches = drive.eligible_branches.split(',') if drive.eligible_branches else []
            if not branches or student.branch in branches:
                applied = Application.query.filter_by(
                    student_id=student.id, 
                    drive_id=drive.id
                ).first()
                if not applied:
                    eligible_drives.append(drive)
    
    applications = Application.query.filter_by(student_id=student.id).all()
    
    notifications = Notification.query.filter_by(
        user_id=current_user.id, 
        is_read=False
    ).order_by(Notification.created_at.desc()).limit(5).all()
    
    return render_template('student_dashboard.html', 
                         student=student,
                         eligible_drives=eligible_drives,
                         applications=applications,
                         notifications=notifications)

# ============= RESUME / PROFILE =============

@app.route('/resume')
@login_required
@role_required('student')
def resume():
    student = Student.query.filter_by(user_id=current_user.id).first()
    
    if not student:
        enroll_no = f"ENROLL{random.randint(1000, 9999)}"
        while Student.query.filter_by(enrollment_no=enroll_no).first():
            enroll_no = f"ENROLL{random.randint(1000, 9999)}"
        
        student = Student(
            user_id=current_user.id,
            enrollment_no=enroll_no
        )
        db.session.add(student)
        db.session.commit()
    
    # Get skill analysis
    skill_analysis = get_skill_analysis(student)
    
    # Get student skills as set
    student_skills = set()
    if student and student.skills:
        student_skills = set([skill.strip() for skill in student.skills.split(',')])
    
    # Calculate skill gap summary
    total_skills = 0
    matched_skills = 0
    for company in skill_analysis:
        total_skills += len(company['required_skills'])
        matched_skills += len(company['required_skills']) - len(company['missing_skills'])
    
    match_percentage = (matched_skills / total_skills * 100) if total_skills > 0 else 0
    
    skill_gap_summary = {
        'match_percentage': match_percentage
    }
    
    return render_template('resume.html', 
                         student=student,
                         skill_analysis=skill_analysis,
                         student_skills=student_skills,
                         skill_gap_summary=skill_gap_summary)

@app.route('/generate-resume', methods=['POST'])
@login_required
@role_required('student')
def generate_resume():
    student = Student.query.filter_by(user_id=current_user.id).first()
    
    if not student:
        flash('Student profile not found', 'error')
        return redirect(url_for('resume'))
    
    # Update all fields
    student.branch = request.form.get('branch', 'Not Specified')
    student.cgpa = float(request.form.get('cgpa', 0))
    student.semester = int(request.form.get('semester', 1))
    student.tenth_percentage = float(request.form.get('tenth_percentage', 0))
    student.twelfth_percentage = float(request.form.get('twelfth_percentage', 0))
    student.graduation_percentage = float(request.form.get('graduation_percentage', 0))
    student.skills = request.form.get('skills', '')
    student.projects = request.form.get('projects', '')
    student.internships = request.form.get('internships', '')
    student.achievements = request.form.get('achievements', '')
    
    db.session.commit()
    
    flash('Profile updated successfully!', 'success')
    return redirect(url_for('resume'))

@app.route('/student/update-cgpa', methods=['POST'])
@login_required
@role_required('student')
def update_cgpa_ajax():
    try:
        student = Student.query.filter_by(user_id=current_user.id).first()
        new_cgpa = float(request.form.get('cgpa'))
        student.cgpa = new_cgpa
        db.session.commit()
        return jsonify({'success': True, 'cgpa': new_cgpa})
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)})

# ============= TPO DASHBOARD =============

@app.route('/tpo/dashboard')
@login_required
@role_required('tpo')
def tpo_dashboard():
    # Get statistics
    total_students = Student.query.count()
    total_drives = Drive.query.count()
    upcoming_drives = Drive.query.filter_by(status='upcoming').count()
    total_applications = Application.query.count()
    
    # Get placed students count
    placed_students = Application.query.filter_by(status='selected').distinct(Application.student_id).count()
    
    # Get recent drives
    recent_drives = Drive.query.order_by(Drive.created_at.desc()).limit(5).all()
    
    # Calculate eligible students for each drive
    drives_with_eligibility = []
    for drive in recent_drives:
        eligible_count = len(find_eligible_students(drive))
        application_count = Application.query.filter_by(drive_id=drive.id).count()
        drives_with_eligibility.append({
            'drive': drive,
            'eligible_count': eligible_count,
            'application_count': application_count
        })
    
    # Get branch-wise student count
    branch_counts = db.session.query(
        Student.branch, 
        db.func.count(Student.id).label('count')
    ).group_by(Student.branch).all()
    
    # If no branches, show default
    if not branch_counts:
        branch_counts = [('Not Specified', total_students)]
    
    return render_template('tpo_dashboard.html',
                         total_students=total_students,
                         total_drives=total_drives,
                         upcoming_drives=upcoming_drives,
                         total_applications=total_applications,
                         placed_students=placed_students,
                         drives_with_eligibility=drives_with_eligibility,
                         branch_counts=branch_counts)

@app.route('/tpo/students')
@login_required
@role_required('tpo')
def tpo_students():
    # Get all students with their user details
    students = db.session.query(Student, User).join(User, Student.user_id == User.id).all()
    return render_template('tpo_students.html', students=students)

@app.route('/tpo/drives')
@login_required
@role_required('tpo')
def tpo_drives():
    # Get all drives
    drives = Drive.query.order_by(Drive.created_at.desc()).all()
    drives_with_stats = []
    
    for drive in drives:
        eligible_count = len(find_eligible_students(drive))
        application_count = Application.query.filter_by(drive_id=drive.id).count()
        drives_with_stats.append({
            'drive': drive,
            'eligible_count': eligible_count,
            'application_count': application_count
        })
    
    return render_template('tpo_drives.html', drives_with_stats=drives_with_stats)

@app.route('/tpo/applications')
@login_required
@role_required('tpo')
def tpo_applications():
    # Get all applications with student and drive details
    applications = db.session.query(Application, Student, User, Drive).\
        join(Student, Application.student_id == Student.id).\
        join(User, Student.user_id == User.id).\
        join(Drive, Application.drive_id == Drive.id).\
        all()
    
    return render_template('tpo_applications.html', applications=applications)

@app.route('/tpo/scheduler')
@login_required
@role_required('tpo')
def tpo_scheduler():
    # Get all applications
    applications = db.session.query(Application, Student, User, Drive).\
        join(Student, Application.student_id == Student.id).\
        join(User, Student.user_id == User.id).\
        join(Drive, Application.drive_id == Drive.id).\
        all()
    
    # Convert to list of Application objects
    interviews = [app for app, _, _, _ in applications]
    
    return render_template('tpo_scheduler.html', 
                         interviews=interviews,
                         now=datetime.now)

@app.route('/tpo/schedule-interview', methods=['POST'])
@login_required
@role_required('tpo')
def schedule_interview():
    application_id = request.form.get('application_id')
    interview_date = datetime.strptime(request.form.get('interview_date'), '%Y-%m-%dT%H:%M')
    interview_slot = request.form.get('slot')
    
    application = Application.query.get(application_id)
    application.interview_date = interview_date
    application.interview_slot = interview_slot
    application.status = 'interview'
    
    # Notify student
    student = Student.query.get(application.student_id)
    notification = Notification(
        user_id=student.user_id,
        title="Interview Scheduled",
        message=f"Your interview for {application.drive.company_name} is scheduled on {interview_date.strftime('%d-%m-%Y %H:%M')}",
        type='application'
    )
    db.session.add(notification)
    
    db.session.commit()
    
    flash('Interview scheduled successfully!', 'success')
    return redirect(url_for('tpo_scheduler'))

@app.route('/drive/<int:drive_id>/applications')
@login_required
@role_required('tpo')
def view_drive_applications(drive_id):
    drive = Drive.query.get_or_404(drive_id)
    applications = db.session.query(Application, Student, User).\
        join(Student, Application.student_id == Student.id).\
        join(User, Student.user_id == User.id).\
        filter(Application.drive_id == drive_id).\
        all()
    
    return render_template('drive_applications.html', drive=drive, applications=applications)

@app.route('/application/<int:application_id>/update-status', methods=['POST'])
@login_required
@role_required('tpo')
def update_application_status(application_id):
    application = Application.query.get_or_404(application_id)
    new_status = request.form.get('status')
    
    application.status = new_status
    
    # Notify student
    student = Student.query.get(application.student_id)
    notification = Notification(
        user_id=student.user_id,
        title=f"Application Status Updated",
        message=f"Your application for {application.drive.company_name} is now {new_status}",
        type='application'
    )
    db.session.add(notification)
    
    db.session.commit()
    
    flash(f'Application status updated to {new_status}', 'success')
    return redirect(url_for('tpo_applications'))

# ============= DRIVE MANAGEMENT =============

@app.route('/drive/create', methods=['GET', 'POST'])
@login_required
@role_required('tpo')
def create_drive():
    if request.method == 'POST':
        drive = Drive(
            company_name=request.form.get('company_name'),
            job_title=request.form.get('job_title'),
            description=request.form.get('description'),
            min_cgpa=float(request.form.get('min_cgpa')),
            max_backlogs=int(request.form.get('max_backlogs')),
            eligible_branches=request.form.get('eligible_branches'),
            eligible_courses=request.form.get('eligible_courses'),
            package=request.form.get('package'),
            location=request.form.get('location'),
            last_date=datetime.strptime(request.form.get('last_date'), '%Y-%m-%d'),
            drive_date=datetime.strptime(request.form.get('drive_date'), '%Y-%m-%d'),
            created_by=current_user.id
        )
        
        db.session.add(drive)
        db.session.commit()
        
        eligible_students = find_eligible_students(drive)
        
        flash(f'Drive created successfully! {len(eligible_students)} students are eligible.', 'success')
        return redirect(url_for('tpo_dashboard'))
    
    return render_template('create_drive.html')

@app.route('/drive/<int:drive_id>/apply')
@login_required
@role_required('student')
def apply_drive(drive_id):
    student = Student.query.filter_by(user_id=current_user.id).first()
    drive = Drive.query.get_or_404(drive_id)
    
    if student.cgpa < drive.min_cgpa:
        flash(f'Your CGPA ({student.cgpa}) is below the required minimum ({drive.min_cgpa})', 'error')
        return redirect(url_for('student_dashboard'))
    
    existing = Application.query.filter_by(
        student_id=student.id,
        drive_id=drive_id
    ).first()
    
    if existing:
        flash('You have already applied for this drive.', 'warning')
        return redirect(url_for('student_dashboard'))
    
    application = Application(
        student_id=student.id,
        drive_id=drive_id,
        status='applied'
    )
    
    db.session.add(application)
    db.session.commit()
    
    flash('Application submitted successfully!', 'success')
    return redirect(url_for('student_dashboard'))

# ============= ALUMNI DASHBOARD =============

@app.route('/alumni/dashboard')
@login_required
@role_required('alumni')
def alumni_dashboard():
    alumni = Alumni.query.filter_by(user_id=current_user.id).first()
    
    if not alumni:
        alumni = Alumni(
            user_id=current_user.id,
            company='Not Specified',
            position='Not Specified',
            batch=datetime.now().year - 1
        )
        db.session.add(alumni)
        db.session.commit()
        flash('Please complete your profile with your company details!', 'info')
    
    # Get referrals
    referrals = JobReferral.query.filter_by(alumni_id=alumni.id).all()
    
    # Get mentorship sessions
    mentorship_sessions = MentorshipSession.query.filter_by(
        alumni_id=alumni.id
    ).order_by(MentorshipSession.date_time.desc()).all()
    
    return render_template('alumni_dashboard.html',
                         alumni=alumni,
                         referrals=referrals,
                         mentorship_sessions=mentorship_sessions,
                         now=datetime.utcnow)

@app.route('/alumni/update-profile', methods=['POST'])
@login_required
@role_required('alumni')
def update_alumni_profile():
    alumni = Alumni.query.filter_by(user_id=current_user.id).first()
    
    company = request.form.get('company')
    position = request.form.get('position')
    batch = request.form.get('batch')
    linkedin = request.form.get('linkedin')
    
    if company:
        alumni.company = company
    if position:
        alumni.position = position
    if batch:
        alumni.batch = int(batch)
    if linkedin:
        alumni.linkedin = linkedin
    
    db.session.commit()
    
    flash(f'Profile updated! You are now working at {alumni.company}', 'success')
    return redirect(url_for('alumni_dashboard'))

@app.route('/alumni/update-mentorship', methods=['POST'])
@login_required
@role_required('alumni')
def update_mentorship_status():
    data = request.get_json()
    alumni = Alumni.query.filter_by(user_id=current_user.id).first()
    alumni.available_for_mentorship = data.get('available', False)
    db.session.commit()
    return jsonify({'success': True})

@app.route('/referral/post', methods=['GET', 'POST'])
@login_required
@role_required('alumni')
def post_referral():
    if request.method == 'POST':
        alumni = Alumni.query.filter_by(user_id=current_user.id).first()
        
        referral = JobReferral(
            alumni_id=alumni.id,
            company=request.form.get('company'),
            position=request.form.get('position'),
            description=request.form.get('description'),
            requirements=request.form.get('requirements'),
            experience_level=request.form.get('experience_level'),
            location=request.form.get('location'),
            apply_link=request.form.get('apply_link'),
            expires_on=datetime.strptime(request.form.get('expires_on'), '%Y-%m-%d')
        )
        
        db.session.add(referral)
        db.session.commit()
        
        flash('Job referral posted successfully!', 'success')
        return redirect(url_for('alumni_dashboard'))
    
    return render_template('post_referral.html')

@app.route('/mentorship/book', methods=['POST'])
@login_required
@role_required('student')
def book_mentorship():
    alumni_id = request.form.get('alumni_id')
    topic = request.form.get('topic')
    date_time = datetime.strptime(request.form.get('date_time'), '%Y-%m-%dT%H:%M')
    duration = int(request.form.get('duration'))
    
    student = Student.query.filter_by(user_id=current_user.id).first()
    
    session_mentor = MentorshipSession(
        alumni_id=alumni_id,
        student_id=student.id,
        topic=topic,
        date_time=date_time,
        duration=duration
    )
    
    db.session.add(session_mentor)
    
    # Notify alumni
    alumni = Alumni.query.get(alumni_id)
    notification = Notification(
        user_id=alumni.user_id,
        title="Mentorship Session Booked",
        message=f"{student.user.full_name} has booked a mentorship session on {date_time.strftime('%d-%m-%Y %H:%M')}",
        type='mentorship'
    )
    db.session.add(notification)
    
    db.session.commit()
    
    flash('Mentorship session booked successfully!', 'success')
    return redirect(url_for('student_dashboard'))

# ============= ANALYTICS =============

@app.route('/analytics')
@login_required
def analytics():
    if current_user.role == 'student':
        student = Student.query.filter_by(user_id=current_user.id).first()
        skill_gap_analysis = get_skill_analysis(student)
        return render_template('analytics.html', student=student, skill_gap=skill_gap_analysis)
    
    elif current_user.role == 'tpo':
        placed_count = Application.query.filter_by(status='selected').count()
        total_students = Student.query.count()
        
        return render_template('analytics.html', 
                             placed_count=placed_count,
                             total_students=total_students)
    
    return redirect(url_for('home'))

# ============= BOT =============

@app.route('/bot', methods=['GET', 'POST'])
@login_required
def bot():
    if request.method == 'POST':
        query = request.json.get('query', '')
        response = get_bot_response(query, current_user)
        
        chat_query = ChatbotQuery(
            user_id=current_user.id,
            query=query,
            response=response
        )
        db.session.add(chat_query)
        db.session.commit()
        
        return jsonify({'response': response})
    
    return render_template('bot.html')

def get_bot_response(query, user):
    query = query.lower()
    
    if 'cgpa' in query:
        if user.role == 'student':
            student = Student.query.filter_by(user_id=user.id).first()
            return f"Your current CGPA is {student.cgpa if student else 'N/A'}. Update it in your profile to see eligible drives."
    
    elif 'eligible' in query or 'drive' in query:
        if user.role == 'student':
            student = Student.query.filter_by(user_id=user.id).first()
            if student and student.cgpa > 0:
                eligible = Drive.query.filter(Drive.min_cgpa <= student.cgpa).count()
                return f"Based on your CGPA of {student.cgpa}, you are eligible for {eligible} drives."
            else:
                return "Please update your CGPA in your profile first."
    
    elif 'hello' in query or 'hi' in query:
        return f"Hello {user.full_name}! How can I help you today?"
    
    else:
        return "I can help you with CGPA, eligible drives, applications, and more!"

# ============= NOTIFICATIONS =============

@app.route('/notifications/mark-read/<int:notification_id>')
@login_required
def mark_notification_read(notification_id):
    notification = Notification.query.get_or_404(notification_id)
    if notification.user_id == current_user.id:
        notification.is_read = True
        db.session.commit()
    return redirect(request.referrer or url_for('dashboard'))

@app.route('/home')
@login_required
def home():
    return render_template('home.html')

@app.route('/check-users')
def check_users():
    users = User.query.all()
    output = "<h2>Users in Database:</h2><ul>"
    for user in users:
        output += f"<li>{user.email} - Role: {user.role}</li>"
    output += "</ul>"
    return output

@app.route('/setup-test-users')
def setup_test_users():
    db.drop_all()
    db.create_all()
    
    # Create TPO
    tpo = User(
        username='tpo',
        email='tpo@college.edu',
        password_hash=generate_password_hash('admin123'),
        role='tpo',
        full_name='Dr. Placement Officer'
    )
    db.session.add(tpo)
    
    # Create Student 1
    student1_user = User(
        username='john',
        email='john@college.edu',
        password_hash=generate_password_hash('student123'),
        role='student',
        full_name='John Doe'
    )
    db.session.add(student1_user)
    db.session.flush()
    
    student1 = Student(
        user_id=student1_user.id,
        enrollment_no='2024CS001',
        branch='Computer Science',
        semester=6,
        cgpa=8.5,
        skills='Python, Java, SQL'
    )
    db.session.add(student1)
    
    # Create Student 2
    student2_user = User(
        username='jane',
        email='jane@college.edu',
        password_hash=generate_password_hash('student123'),
        role='student',
        full_name='Jane Smith'
    )
    db.session.add(student2_user)
    db.session.flush()
    
    student2 = Student(
        user_id=student2_user.id,
        enrollment_no='2024CS002',
        branch='Information Technology',
        semester=6,
        cgpa=7.8,
        skills='JavaScript, React, HTML, CSS'
    )
    db.session.add(student2)
    
    # Create Student 3
    student3_user = User(
        username='bob',
        email='bob@college.edu',
        password_hash=generate_password_hash('student123'),
        role='student',
        full_name='Bob Wilson'
    )
    db.session.add(student3_user)
    db.session.flush()
    
    student3 = Student(
        user_id=student3_user.id,
        enrollment_no='2024CS003',
        branch='MCA',
        semester=4,
        cgpa=9.2,
        skills='Python, Django, SQL, AWS'
    )
    db.session.add(student3)
    
    # Create Alumni with company
    alumni_user = User(
        username='hagyashree',
        email='hagyashree@alumni.com',
        password_hash=generate_password_hash('alumni123'),
        role='alumni',
        full_name='Hagyashree'
    )
    db.session.add(alumni_user)
    db.session.flush()
    
    alumni = Alumni(
        user_id=alumni_user.id,
        company='Google',
        position='Senior Software Engineer',
        batch=2020,
        linkedin='https://linkedin.com/in/hagyashree'
    )
    db.session.add(alumni)
    
    # Create drives
    drive1 = Drive(
        company_name='Google',
        job_title='Software Engineer',
        description='Software Development Engineer',
        min_cgpa=7.0,
        max_backlogs=0,
        eligible_branches='Computer Science,Information Technology,MCA',
        package='25 LPA',
        location='Bangalore',
        last_date=datetime.utcnow() + timedelta(days=10),
        drive_date=datetime.utcnow() + timedelta(days=20),
        status='upcoming',
        created_by=tpo.id
    )
    db.session.add(drive1)
    
    drive2 = Drive(
        company_name='Microsoft',
        job_title='SDE',
        description='Software Development Engineer',
        min_cgpa=8.0,
        max_backlogs=0,
        eligible_branches='Computer Science',
        package='30 LPA',
        location='Hyderabad',
        last_date=datetime.utcnow() + timedelta(days=15),
        drive_date=datetime.utcnow() + timedelta(days=25),
        status='upcoming',
        created_by=tpo.id
    )
    db.session.add(drive2)
    
    drive3 = Drive(
        company_name='Wipro',
        job_title='Tech Manager',
        description='Technical Manager',
        min_cgpa=6.0,
        max_backlogs=2,
        eligible_branches='Computer Science,Information Technology,MCA,Electronics',
        package='8 LPA',
        location='Pune',
        last_date=datetime.utcnow() + timedelta(days=5),
        drive_date=datetime.utcnow() + timedelta(days=15),
        status='upcoming',
        created_by=tpo.id
    )
    db.session.add(drive3)
    
    db.session.commit()
    
    return """
    <html>
    <head><title>Setup Complete</title></head>
    <body style="font-family: Arial; padding: 2rem;">
        <h2 style="color: #4caf50;">✅ Test Users Created Successfully!</h2>
        <div style="background: #f5f5f5; padding: 1rem; border-radius: 10px;">
            <h3>Login Credentials:</h3>
            <p><strong>TPO:</strong> tpo@college.edu / admin123</p>
            <p><strong>Students:</strong> john@college.edu / student123, jane@college.edu / student123, bob@college.edu / student123</p>
            <p><strong>Alumni:</strong> hagyashree@alumni.com / alumni123 (Google)</p>
        </div>
        <p><a href="/login" style="background: #4361ee; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px;">Go to Login</a></p>
    </body>
    </html>
    """

# Initialize database
with app.app_context():
    db.create_all()
    print("✅ Database initialized!")
    print("👥 Total users:", User.query.count())
    print("👨‍🎓 Total students:", Student.query.count())
    print("👩‍🎓 Total alumni:", Alumni.query.count())

if __name__ == '__main__':
    app.run(debug=True)