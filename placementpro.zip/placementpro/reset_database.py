# reset_database.py
import os
from app import app, db, User, Student, Alumni, Drive
from werkzeug.security import generate_password_hash
from datetime import datetime, timedelta

def reset_database():
    print("🔄 Creating new database...")
    
    with app.app_context():
        # Create all tables
        db.create_all()
        print("✅ Created database tables")
        
        # Create TPO user
        tpo = User(
            username='tpo',
            email='tpo@college.edu',
            password_hash=generate_password_hash('admin123'),
            role='tpo',
            full_name='Dr. Placement Officer',
            verified=True
        )
        db.session.add(tpo)
        
        # Create Student user
        student = User(
            username='john_student',
            email='john@college.edu',
            password_hash=generate_password_hash('student123'),
            role='student',
            full_name='John Doe',
            verified=True
        )
        db.session.add(student)
        db.session.flush()
        
        # Create Student profile
        student_profile = Student(
            user_id=student.id,
            enrollment_no='2024CS001',
            branch='Computer Science',
            semester=6,
            cgpa=8.5,
            backlogs=0,
            tenth_percentage=89.5,
            twelfth_percentage=87.0,
            graduation_percentage=85.0,
            skills='Python, Java, SQL, JavaScript'
        )
        db.session.add(student_profile)
        
        # Create Alumni user
        alumni = User(
            username='jane_alumni',
            email='jane@alumni.com',
            password_hash=generate_password_hash('alumni123'),
            role='alumni',
            full_name='Jane Smith',
            verified=True
        )
        db.session.add(alumni)
        db.session.flush()
        
        # Create Alumni profile
        alumni_profile = Alumni(
            user_id=alumni.id,
            company='Google',
            position='Senior Software Engineer',
            batch=2020,
            linkedin='https://linkedin.com/in/janesmith',
            available_for_mentorship=True
        )
        db.session.add(alumni_profile)
        
        # Create a sample drive
        drive = Drive(
            company_name='Google',
            job_title='Software Engineer',
            description='Great opportunity for software engineers',
            min_cgpa=7.0,
            max_backlogs=0,
            eligible_branches='Computer Science,Information Technology,MCA',
            package='25 LPA',
            location='Bangalore',
            last_date=datetime.utcnow() + timedelta(days=10),
            drive_date=datetime.utcnow() + timedelta(days=20),
            status='upcoming',
            created_by=tpo.id
        )
        db.session.add(drive)
        
        db.session.commit()
        
        print("\n" + "="*50)
        print("✅ DATABASE CREATED SUCCESSFULLY!")
        print("="*50)
        print("\nTest Users Created:")
        print("-"*30)
        print("TPO:     tpo@college.edu / admin123")
        print("Student: john@college.edu / student123")
        print("Alumni:  jane@alumni.com / alumni123")
        print("="*50)
        
        # Verify tables were created
        tables = db.engine.table_names()
        print("\n📊 Tables in database:")
        for table in tables:
            print(f"  - {table}")

if __name__ == '__main__':
    reset_database()