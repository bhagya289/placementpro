# clean_reset.py
import os
import sqlite3
from werkzeug.security import generate_password_hash
from datetime import datetime, timedelta

def clean_reset():
    print("=" * 60)
    print("🧹 COMPLETE CLEAN RESET")
    print("=" * 60)
    
    # Delete any existing database
    db_path = 'placementpro.db'
    if os.path.exists(db_path):
        try:
            os.remove(db_path)
            print(f"✅ Deleted: {db_path}")
        except:
            print(f"⚠️ Could not delete {db_path}, but continuing...")
    
    # Create new database
    print("\n📦 Creating new database...")
    try:
        conn = sqlite3.connect(db_path)
        cursor = conn.cursor()
        print("✅ Database connection created")
    except Exception as e:
        print(f"❌ Failed to create database: {e}")
        return False
    
    # Create users table
    print("\n📦 Creating users table...")
    try:
        cursor.execute('''
        CREATE TABLE users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username VARCHAR(80) UNIQUE NOT NULL,
            email VARCHAR(120) UNIQUE NOT NULL,
            password_hash VARCHAR(200) NOT NULL,
            role VARCHAR(20) NOT NULL,
            full_name VARCHAR(100),
            profile_pic VARCHAR(200),
            verified BOOLEAN DEFAULT 0,
            created_at DATETIME
        )
        ''')
        print("✅ Users table created")
        
        # Verify the table
        cursor.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='users'")
        if cursor.fetchone():
            print("  ✓ Users table verified")
            
            # Check columns
            cursor.execute("PRAGMA table_info(users)")
            columns = cursor.fetchall()
            print("\n📊 Users table columns:")
            verified_found = False
            for col in columns:
                col_name = col[1]
                col_type = col[2]
                if col_name == 'verified':
                    verified_found = True
                    print(f"  • {col_name} ({col_type}) ✅ VERIFIED COLUMN")
                else:
                    print(f"  • {col_name} ({col_type})")
            
            if not verified_found:
                print("❌ ERROR: verified column missing!")
                return False
    except Exception as e:
        print(f"❌ Failed to create users table: {e}")
        return False
    
    # Create students table
    print("\n📦 Creating students table...")
    try:
        cursor.execute('''
        CREATE TABLE students (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER UNIQUE,
            enrollment_no VARCHAR(20) UNIQUE,
            branch VARCHAR(50),
            semester INTEGER,
            cgpa FLOAT,
            backlogs INTEGER DEFAULT 0,
            tenth_percentage FLOAT,
            twelfth_percentage FLOAT,
            graduation_percentage FLOAT,
            skills TEXT,
            projects TEXT,
            internships TEXT,
            achievements TEXT,
            resume_url VARCHAR(200),
            FOREIGN KEY (user_id) REFERENCES users (id)
        )
        ''')
        print("✅ Students table created")
    except Exception as e:
        print(f"❌ Failed to create students table: {e}")
        return False
    
    # Create alumni table
    print("\n📦 Creating alumni table...")
    try:
        cursor.execute('''
        CREATE TABLE alumni (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER UNIQUE,
            company VARCHAR(100),
            position VARCHAR(100),
            batch INTEGER,
            linkedin VARCHAR(200),
            available_for_mentorship BOOLEAN DEFAULT 0,
            mentorship_hours VARCHAR(200),
            FOREIGN KEY (user_id) REFERENCES users (id)
        )
        ''')
        print("✅ Alumni table created")
    except Exception as e:
        print(f"❌ Failed to create alumni table: {e}")
        return False
    
    # Create drives table
    print("\n📦 Creating drives table...")
    try:
        cursor.execute('''
        CREATE TABLE drives (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            company_name VARCHAR(100),
            job_title VARCHAR(100),
            description TEXT,
            min_cgpa FLOAT,
            max_backlogs INTEGER,
            eligible_branches TEXT,
            eligible_courses TEXT,
            package VARCHAR(50),
            location VARCHAR(100),
            last_date DATETIME,
            drive_date DATETIME,
            status VARCHAR(20) DEFAULT 'upcoming',
            created_by INTEGER,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (created_by) REFERENCES users (id)
        )
        ''')
        print("✅ Drives table created")
    except Exception as e:
        print(f"❌ Failed to create drives table: {e}")
        return False
    
    # Create applications table
    print("\n📦 Creating applications table...")
    try:
        cursor.execute('''
        CREATE TABLE applications (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            student_id INTEGER,
            drive_id INTEGER,
            status VARCHAR(20) DEFAULT 'applied',
            applied_date DATETIME DEFAULT CURRENT_TIMESTAMP,
            interview_date DATETIME,
            interview_slot VARCHAR(50),
            feedback TEXT,
            FOREIGN KEY (student_id) REFERENCES students (id),
            FOREIGN KEY (drive_id) REFERENCES drives (id)
        )
        ''')
        print("✅ Applications table created")
    except Exception as e:
        print(f"❌ Failed to create applications table: {e}")
        return False
    
    # Create job_referrals table
    print("\n📦 Creating job_referrals table...")
    try:
        cursor.execute('''
        CREATE TABLE job_referrals (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            alumni_id INTEGER,
            company VARCHAR(100),
            position VARCHAR(100),
            description TEXT,
            requirements TEXT,
            experience_level VARCHAR(50),
            location VARCHAR(100),
            apply_link VARCHAR(200),
            posted_date DATETIME DEFAULT CURRENT_TIMESTAMP,
            expires_on DATETIME,
            FOREIGN KEY (alumni_id) REFERENCES alumni (id)
        )
        ''')
        print("✅ Job referrals table created")
    except Exception as e:
        print(f"❌ Failed to create job_referrals table: {e}")
        return False
    
    # Create mentorship_sessions table
    print("\n📦 Creating mentorship_sessions table...")
    try:
        cursor.execute('''
        CREATE TABLE mentorship_sessions (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            alumni_id INTEGER,
            student_id INTEGER,
            topic VARCHAR(200),
            date_time DATETIME,
            duration INTEGER,
            status VARCHAR(20) DEFAULT 'scheduled',
            notes TEXT,
            FOREIGN KEY (alumni_id) REFERENCES alumni (id),
            FOREIGN KEY (student_id) REFERENCES students (id)
        )
        ''')
        print("✅ Mentorship sessions table created")
    except Exception as e:
        print(f"❌ Failed to create mentorship_sessions table: {e}")
        return False
    
    # Create notifications table
    print("\n📦 Creating notifications table...")
    try:
        cursor.execute('''
        CREATE TABLE notifications (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER,
            title VARCHAR(200),
            message TEXT,
            type VARCHAR(50),
            is_read BOOLEAN DEFAULT 0,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (user_id) REFERENCES users (id)
        )
        ''')
        print("✅ Notifications table created")
    except Exception as e:
        print(f"❌ Failed to create notifications table: {e}")
        return False
    
    # Create chatbot_queries table
    print("\n📦 Creating chatbot_queries table...")
    try:
        cursor.execute('''
        CREATE TABLE chatbot_queries (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER,
            query TEXT,
            response TEXT,
            timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (user_id) REFERENCES users (id)
        )
        ''')
        print("✅ Chatbot queries table created")
    except Exception as e:
        print(f"❌ Failed to create chatbot_queries table: {e}")
        return False
    
    # Insert test users
    print("\n👤 Inserting test users...")
    try:
        # Generate password hashes
        admin_hash = generate_password_hash('admin123')
        student_hash = generate_password_hash('student123')
        alumni_hash = generate_password_hash('alumni123')
        
        # Insert TPO
        cursor.execute('''
        INSERT INTO users (username, email, password_hash, role, full_name, verified, created_at)
        VALUES (?, ?, ?, ?, ?, ?, ?)
        ''', ('tpo', 'tpo@college.edu', admin_hash, 'tpo', 'Dr. Placement Officer', 1, datetime.now()))
        tpo_id = cursor.lastrowid
        print(f"  ✓ TPO user inserted (ID: {tpo_id})")
        
        # Insert Student
        cursor.execute('''
        INSERT INTO users (username, email, password_hash, role, full_name, verified, created_at)
        VALUES (?, ?, ?, ?, ?, ?, ?)
        ''', ('john_student', 'john@college.edu', student_hash, 'student', 'John Doe', 1, datetime.now()))
        student_user_id = cursor.lastrowid
        print(f"  ✓ Student user inserted (ID: {student_user_id})")
        
        # Insert Student profile
        cursor.execute('''
        INSERT INTO students (user_id, enrollment_no, branch, semester, cgpa, backlogs, 
                             tenth_percentage, twelfth_percentage, graduation_percentage, skills)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        ''', (student_user_id, '2024CS001', 'Computer Science', 6, 8.5, 0, 89.5, 87.0, 85.0, 
              'Python, Java, SQL, JavaScript'))
        print("  ✓ Student profile inserted")
        
        # Insert Alumni
        cursor.execute('''
        INSERT INTO users (username, email, password_hash, role, full_name, verified, created_at)
        VALUES (?, ?, ?, ?, ?, ?, ?)
        ''', ('jane_alumni', 'jane@alumni.com', alumni_hash, 'alumni', 'Jane Smith', 1, datetime.now()))
        alumni_user_id = cursor.lastrowid
        print(f"  ✓ Alumni user inserted (ID: {alumni_user_id})")
        
        # Insert Alumni profile
        cursor.execute('''
        INSERT INTO alumni (user_id, company, position, batch, linkedin, available_for_mentorship)
        VALUES (?, ?, ?, ?, ?, ?)
        ''', (alumni_user_id, 'Google', 'Senior Software Engineer', 2020, 
              'https://linkedin.com/in/janesmith', 1))
        print("  ✓ Alumni profile inserted")
        
        # Insert a sample drive
        cursor.execute('''
        INSERT INTO drives (company_name, job_title, description, min_cgpa, max_backlogs, 
                           eligible_branches, package, location, last_date, drive_date, status, created_by)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        ''', ('Google', 'Software Engineer', 'Great opportunity for software engineers', 
              7.0, 0, 'Computer Science,Information Technology,MCA', '25 LPA', 'Bangalore',
              (datetime.now() + timedelta(days=10)).isoformat(),
              (datetime.now() + timedelta(days=20)).isoformat(),
              'upcoming', tpo_id))
        print("  ✓ Sample drive inserted")
        
        # Commit all changes
        conn.commit()
        print("\n✅ All data committed successfully")
        
    except Exception as e:
        print(f"❌ Failed to insert data: {e}")
        conn.rollback()
        return False
    
    # Final verification
    print("\n🔍 FINAL VERIFICATION:")
    print("-" * 40)
    
    try:
        # Check users
        cursor.execute("SELECT id, email, role, verified FROM users")
        users = cursor.fetchall()
        print(f"\n👥 Users in database ({len(users)}):")
        for user in users:
            verified = "✅ Verified" if user[3] == 1 else "❌ Not Verified"
            print(f"  • {user[1]} ({user[2]}) - {verified}")
        
        # Check students
        cursor.execute("SELECT COUNT(*) FROM students")
        student_count = cursor.fetchone()[0]
        print(f"\n👨‍🎓 Students: {student_count}")
        
        # Check alumni
        cursor.execute("SELECT COUNT(*) FROM alumni")
        alumni_count = cursor.fetchone()[0]
        print(f"👩‍🎓 Alumni: {alumni_count}")
        
        # Check drives
        cursor.execute("SELECT COUNT(*) FROM drives")
        drives_count = cursor.fetchone()[0]
        print(f"📋 Drives: {drives_count}")
        
    except Exception as e:
        print(f"❌ Failed to verify data: {e}")
    
    conn.close()
    
    print("\n" + "=" * 60)
    print("✅ CLEAN RESET COMPLETED SUCCESSFULLY!")
    print("=" * 60)
    print("\n📝 LOGIN CREDENTIALS:")
    print("-" * 40)
    print("TPO:     tpo@college.edu / admin123")
    print("Student: john@college.edu / student123")
    print("Alumni:  jane@alumni.com / alumni123")
    print("-" * 40)
    
    return True

if __name__ == '__main__':
    success = clean_reset()
    if success:
        print("\n🚀 You can now run: python app.py")
    else:
        print("\n❌ Reset failed. Please check the errors above.")