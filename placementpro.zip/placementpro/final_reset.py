# final_reset.py
import os
import sqlite3
import sys
from app import app, db
from werkzeug.security import generate_password_hash
from datetime import datetime, timedelta

def final_reset():
    print("=" * 60)
    print("🔧 PLACEMENTPRO DATABASE RESET UTILITY")
    print("=" * 60)
    
    # Step 1: Delete existing database
    db_path = 'placementpro.db'
    if os.path.exists(db_path):
        os.remove(db_path)
        print(f"✅ Deleted existing database: {db_path}")
    else:
        print("ℹ️ No existing database found")
    
    # Step 2: Create fresh database with SQLAlchemy
    print("\n📦 Creating fresh database tables...")
    with app.app_context():
        # Create all tables
        db.create_all()
        print("✅ Tables created successfully")
        
        # Step 3: Verify the schema directly with SQLite
        conn = sqlite3.connect(db_path)
        cursor = conn.cursor()
        
        # Check users table schema
        cursor.execute("PRAGMA table_info(users)")
        columns = cursor.fetchall()
        
        print("\n📊 VERIFIED COLUMNS IN USERS TABLE:")
        print("-" * 40)
        verified_found = False
        for col in columns:
            col_name = col[1]
            col_type = col[2]
            is_verified = "✅ VERIFIED COLUMN" if col_name == 'verified' else ""
            if col_name == 'verified':
                verified_found = True
            print(f"  • {col_name:20} ({col_type:10}) {is_verified}")
        
        if not verified_found:
            print("\n❌ CRITICAL ERROR: 'verified' column still missing!")
            print("This should not happen. Please check your model definition.")
            conn.close()
            return False
        
        conn.close()
        
        # Step 4: Create test users
        print("\n👤 Creating test users...")
        
        try:
            # Create TPO user
            tpo = User(
                username='tpo',
                email='tpo@college.edu',
                password_hash=generate_password_hash('admin123'),
                role='tpo',
                full_name='Dr. Placement Officer',
                verified=True
            )
            db.session.add(tpo)
            db.session.flush()
            print("  ✓ TPO user created")
            
            # Create Student user
            student = User(
                username='john_student',
                email='john@college.edu',
                password_hash=generate_password_hash('student123'),
                role='student',
                full_name='John Doe',
                verified=True
            )
            db.session.add(student)
            db.session.flush()
            print("  ✓ Student user created")
            
            # Create Student profile
            student_profile = Student(
                user_id=student.id,
                enrollment_no='2024CS001',
                branch='Computer Science',
                semester=6,
                cgpa=8.5,
                backlogs=0,
                tenth_percentage=89.5,
                twelfth_percentage=87.0,
                graduation_percentage=85.0,
                skills='Python, Java, SQL, JavaScript'
            )
            db.session.add(student_profile)
            print("  ✓ Student profile created")
            
            # Create Alumni user
            alumni = User(
                username='jane_alumni',
                email='jane@alumni.com',
                password_hash=generate_password_hash('alumni123'),
                role='alumni',
                full_name='Jane Smith',
                verified=True
            )
            db.session.add(alumni)
            db.session.flush()
            print("  ✓ Alumni user created")
            
            # Create Alumni profile
            alumni_profile = Alumni(
                user_id=alumni.id,
                company='Google',
                position='Senior Software Engineer',
                batch=2020,
                linkedin='https://linkedin.com/in/janesmith',
                available_for_mentorship=True
            )
            db.session.add(alumni_profile)
            print("  ✓ Alumni profile created")
            
            # Create a sample drive
            drive = Drive(
                company_name='Google',
                job_title='Software Engineer',
                description='Great opportunity for software engineers',
                min_cgpa=7.0,
                max_backlogs=0,
                eligible_branches='Computer Science,Information Technology,MCA',
                package='25 LPA',
                location='Bangalore',
                last_date=datetime.utcnow() + timedelta(days=10),
                drive_date=datetime.utcnow() + timedelta(days=20),
                status='upcoming',
                created_by=tpo.id
            )
            db.session.add(drive)
            print("  ✓ Sample drive created")
            
            # Commit all changes
            db.session.commit()
            print("\n✅ All data committed to database")
            
        except Exception as e:
            print(f"\n❌ Error creating users: {e}")
            db.session.rollback()
            
            # Print detailed error info
            if hasattr(e, 'statement'):
                print(f"\n📝 SQL Statement: {e.statement}")
            if hasattr(e, 'params'):
                print(f"📝 Parameters: {e.params}")
            return False
        
        # Step 5: Final verification
        print("\n🔍 FINAL VERIFICATION:")
        print("-" * 40)
        
        # Check users
        users = User.query.all()
        print(f"Users in database: {len(users)}")
        for user in users:
            verified_status = "✅ Verified" if user.verified else "❌ Not Verified"
            print(f"  • {user.email} ({user.role}) - {verified_status}")
        
        # Check students
        students = Student.query.all()
        print(f"\nStudents in database: {len(students)}")
        for s in students:
            print(f"  • {s.user.full_name} - {s.branch} - CGPA: {s.cgpa}")
        
        # Check alumni
        alumni_list = Alumni.query.all()
        print(f"\nAlumni in database: {len(alumni_list)}")
        for a in alumni_list:
            print(f"  • {a.user.full_name} - {a.company}")
        
        # Check drives
        drives = Drive.query.all()
        print(f"\nDrives in database: {len(drives)}")
        for d in drives:
            print(f"  • {d.company_name} - {d.job_title}")
        
        print("\n" + "=" * 60)
        print("🎉 DATABASE RESET COMPLETED SUCCESSFULLY!")
        print("=" * 60)
        print("\n📝 LOGIN CREDENTIALS:")
        print("-" * 40)
        print("TPO:     tpo@college.edu / admin123")
        print("Student: john@college.edu / student123")
        print("Alumni:  jane@alumni.com / alumni123")
        print("-" * 40)
        
        return True

if __name__ == '__main__':
    success = final_reset()
    if success:
        print("\n✅ You can now start your Flask app with: python app.py")
        print("🌐 Then visit: http://localhost:5000")
    else:
        print("\n❌ Database reset failed. Please check the errors above.")